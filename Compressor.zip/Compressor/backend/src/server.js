const express = require('express');
const http = require('http');
const cors = require('cors');
const { initWebSocket } = require('./config/websocket');
const apiRoutes = require('./routes/api.routes');

const app = express();
const server = http.createServer(app);

// Inicializa o WebSocket acoplado ao servidor HTTP
initWebSocket(server);

// Middlewares
app.use(cors());
app.use(express.json());

// Rotas da API REST
app.use('/api/v1', apiRoutes);

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`🚀 Servidor rodando na porta ${PORT}`);
});