const { Server } = require('socket.io');

let io;

function initWebSocket(server) {
  io = new Server(server, {
    cors: {
      origin: "*", // Em produção, mude para a URL do seu Front-end
      methods: ["GET", "POST"]
    }
  });

  io.on('connection', (socket) => {
    console.log(`🔌 Novo dispositivo/cliente conectado: ${socket.id}`);
    
    // Vincula os eventos de WebSocket separados
    require('../routes/ws.events')(socket, io);

    socket.on('disconnect', () => {
      console.log(`❌ Conexão encerrada: ${socket.id}`);
    });
  });

  return io;
}

function getIO() {
  if (!io) {
    throw new Error("Socket.io não foi inicializado!");
  }
  return io;
}

module.exports = { initWebSocket, getIO };