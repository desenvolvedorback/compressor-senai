const knex = require('knex');
require('dotenv').config();

const db = knex({
  client: 'pg', // ou 'mysql2'
  connection: {
    host: process.env.DB_HOST || '127.0.0.1',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'suasenha',
    database: process.env.DB_NAME || 'monitoramento_compressores',
    port: process.env.DB_PORT || 5432
  },
  pool: { min: 2, max: 10 }
});

module.exports = db;