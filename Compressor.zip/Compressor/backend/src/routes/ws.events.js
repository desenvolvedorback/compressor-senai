const telemetriaController = require('../controllers/telemetria.controller');

module.exports = (socket, io) => {
  // Ouve o evento de telemetria vindo do compressor/gateway
  socket.on('telemetria:enviar', async (dados) => {
    // dados = { compressor_id, sensor_id, rms, temperatura, estado_trabalho }
    await telemetriaController.processarDados(dados, io);
  });
};