const express = require('express');
const router = express.Router();
const compressorController = require('../controllers/compressor.controller');
const manutencaoController = require('../controllers/manutencao.controller');
const manutencaoSensor = require('../controllers/sensor.controller');

// Rotas de Compressores
router.get('/compressores', compressorController.listarTodos);
router.get(`/compressores/${id}/dashboard`, compressorController.obterDashboard);
router.get(`/compressores/${id}/vibracao-historico`, compressorController.vibracao);

// Rotas de Manutenção
router.post('/manutencao/ordens', manutencaoController.criarOrdem);
router.post('/manutencao/preventivas-pendentes', manutencaoController.preventivas);

//rotas do sensores
router.post('sensores/calibracao', manutencaoSensor.calibracao);

module.exports = router;