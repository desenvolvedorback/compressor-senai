Endpoints principais da API REST (/api/v1)
GET /compressores -> Retorna lista de compressores com status e horímetro atual.

GET /compressores/:id/dashboard -> Dados consolidados das últimas 24h (médias de vibração, alarmes).

GET /compressores/:id/vibracao-historico -> Dados brutos e FFT para gráficos de engenharia preditiva.

POST /manutencao/ordens -> Abertura manual ou automática de ordens de serviço.

GET /manutencao/preventivas-pendentes -> Lista o que está próximo do gatilho de horas/tempo.

POST /sensores/calibracao -> Atualiza a data de calibração do sensor.

Fluxo do WebSocket (Real-Time)
Evento telemetria:enviar (Entrada): O simulador/gateway IoT envia { compressor_id, sensor_id, rms, temperatura, estado_trabalho }.

Lógica Interna: 1. Grava no banco de dados.
2. Compara rms com limite_vibracao_critico. Se estourar, abre Ordem de Serviço Corretiva imediata e dispara alerta.
3. Atualiza o horímetro se o estado for 'carga'. 


O que vai nas outras pastas? (O Guia de Implementação)
Com a estrutura acima rodando (npm run dev), você deve construir a lógica interna seguindo esta divisão de responsabilidades:

1. src/services/ (As Regras de Negócio Ocultas)
analise.service.js: Recebe o valor de vibração (rms), busca os limites do compressor no banco (db('compressores')) e compara. Se o rms estourar o limite crítico, ele chama o manutencao.service.js para abrir uma ordem corretiva imediata.

manutencao.service.js: Contém a lógica de abrir ordens de serviço e recalcular horímetros.

2. src/controllers/ (Os Intermediários)
telemetria.controller.js: É chamado pelo evento do WebSocket. Ele chama o banco de dados para salvar a leitura atual, aciona o analise.service.js para checar anomalias e, se estiver tudo certo, repassa os dados atualizados para o Front-end usando io.emit('telemetria:painel', dados).

compressor.controller.js: Executa as queries SQL (SELECT) para responder às rotas HTTP (/compressores, /dashboard), trazendo as médias das últimas 24 horas.

3. src/jobs/ (Os Operários de Segundo Plano)
cron.jobs.js: Utiliza bibliotecas como node-cron. Ele roda silenciosamente uma vez por dia (ex: às 00:00) disparando uma função que varre a tabela planos_preventiva para checar se algum compressor atingiu a data limite da próxima revisão, abrindo a OS preventiva caso necessário.