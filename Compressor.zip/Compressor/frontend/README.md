Funcionalidades das Telas Principais
Dashboard Geral (Monitoramento Online):

Grade de compressores mostrando status (Operando em verde, Falha em vermelho, Manutenção em amarelo).

Exibição do tempo de trabalho acumulado (Horímetro total) e barra de progresso para a próxima preventiva.

Indicador visual se o compressor está trabalhando "Em Carga" ou "Em Vazio".

Módulo de Mecânica e Vibração:

Gráfico de linha dinâmico atualizado a cada segundo via WebSocket mostrando o valor RMS da vibração.

Linhas horizontais vermelhas e amarelas indicando limites de Alerta e Crítico conforme normas ISO (ex: ISO 10816).

Painel de análise de espectro (FFT) para analistas de preditiva identificarem desalinhamento ou folgas.

Painel de Manutenção Preventiva:

Lista de tarefas preventivas com semáforo de criticidade:

Verde: Longe do prazo.

Amarelo: Dentro de 10% do limite de horas (Ex: 1900h de um plano de 2000h) ou 15 dias do prazo calendário.

Vermelho: Prazo de preventiva estourado.

Botão para dar baixa na preventiva executada, o que recalcula automaticamente os próximos gatilhos no SQL.

5. Lógica de Automação de Manutenção Preventiva (Regra de Negócio)
Para garantir que a manutenção preventiva seja acionada corretamente, o Back-end executa uma rotina inteligente (Job diário ou evento disparado por atualização de horímetro):

JavaScript
// Exemplo conceitual da lógica implementada no Back-end (services/manutencao.service.js)
async function verificarGatilhosPreventivos(compressorId, horasAtuais) {
    // 1. Busca os planos ativos do compressor
    const planos = await db('planos_preventiva').where({ compressor_id: compressorId });
    const dataAtual = new Date();

    for (let plano of planos) {
        let dispararAlerta = false;
        let motivo = "";

        // Verificação por Horas de Trabalho
        if (horasAtuais >= plano.proxima_revisao_horas) {
            dispararAlerta = true;
            motivo = `Horímetro atingiu ${horasAtuais}h (Limite do plano: ${plano.proxima_revisao_horas}h)`;
        }
        
        // Verificação por Tempo Calendário
        if (dataAtual >= new Date(plano.proxima_revisao_data)) {
            dispararAlerta = true;
            motivo = `Data limite atingida: ${plano.proxima_revisao_data.toLocaleDateString()}`;
        }

        // Se algum gatilho estourou, gera a Ordem de Serviço Preventiva automaticamente
        if (dispararAlerta) {
            await db('ordens_manutencao').insert({
                compressor_id: compressorId,
                plano_id: plano.id,
                tipo: 'preventiva',
                status: 'aberta',
                descricao_problema: `Gerado Automaticamente pelo Sistema. Motivo: ${motivo}`
            });
            
            // Emite notificação em tempo real via WebSocket para o Front-end
            io.emit('alerta:manutencao', { compressorId, mensagem: `Preventiva Necessária: ${plano.descricao}` });
        }
    }
}
Este projeto garante o rastreamento ponta a ponta, unindo a velocidade do tempo real necessária para a análise mecânica de vibração com a consistência relacional exigida pela gestão de manutenção industrial.


file_name = "projeto_sistema_compressor.md"
with open(file_name, "w", encoding="utf-8") as f:
f.write(markdown_content)

print(f"File created successfully: {file_name}")


# README.md

# Sistema de Monitoramento de Compressores - Frontend

Frontend em React para o sistema de monitoramento de compressores industriais com análise de vibração e gestão de manutenção preventiva.

## 🚀 Funcionalidades

### Dashboard Principal
- ✅ Grade de compressores com status visual (verde/amarelo/vermelho)
- ✅ Horímetro total e barra de progresso para preventiva
- ✅ Indicador de estado (Carga/Vazio)
- ✅ Alertas em tempo real via WebSocket
- ✅ Estatísticas rápidas (total, em operação, com falha)

### Análise Mecânica
- ✅ Gráfico de vibração RMS em tempo real
- ✅ Linhas de Alerta e Crítico (ISO 10816-3)
- ✅ Estatísticas (média, máximo, mínimo)
- ✅ Painel FFT para análise de espectro
- ✅ Dados técnicos do compressor

### Gestão de Manutenção
- ✅ Tabela de preventivas pendentes
- ✅ Semáforo de criticidade (Verde/Amarelo/Vermelho)
- ✅ Criação automática de ordens de serviço
- ✅ Criação manual de ordens de serviço
- ✅ Feedback visual com Snackbars

## 📦 Tecnologias

- **React 18** - Framework UI
- **Material-UI** - Componentes e estilização
- **Socket.io-client** - Comunicação em tempo real
- **Recharts** - Gráficos interativos
- **Axios** - Requisições HTTP
- **React Router** - Navegação
- **date-fns** - Manipulação de datas

## 🏗️ Estrutura de Pastas

frontend/
├── public/
├── src/
│ ├── assets/
│ │ └── styles.css # Estilos globais
│ ├── components/
│ │ ├── CardCompressor.jsx # Card de status do compressor
│ │ ├── GraficoLinha.jsx # Gráfico de linha em tempo real
│ │ ├── ListaAlertas.jsx # Feed de alertas
│ │ ├── TabelaPreventivas.jsx # Tabela de preventivas
│ │ └── Navigation.jsx # Barra de navegação
│ ├── contexts/
│ │ └── SocketContext.jsx # Contexto WebSocket
│ ├── pages/
│ │ ├── Dashboard.jsx # Tela principal
│ │ ├── AnaliseMecanica.jsx # Análise de vibração
│ │ └── Manutencao.jsx # Gestão de manutenção
│ ├── services/
│ │ └── api.js # Chamadas API
│ ├── App.jsx
│ └── main.jsx
├── package.json
└── README.md

text

## 🔧 Instalação

1. **Clone o repositório**
```bash
git clone https://github.com/desenvolvedorback/compressor-senai.git
cd frontend
Instale as dependências

bash
npm install
Configure as variáveis de ambiente
Crie um arquivo .env na raiz:

env
REACT_APP_API_URL=http://localhost:3000/api/v1
REACT_APP_WS_URL=http://localhost:3000
Inicie o servidor de desenvolvimento

bash
npm start
Acesse a aplicação
Abra http://localhost:3001

📡 Integração WebSocket
Eventos Recebidos
telemetria:painel - Dados de telemetria em tempo real

alerta:manutencao - Alertas de manutenção preventiva

alerta:vibracao - Alertas de vibração crítica

Estrutura dos Dados
javascript
// Telemetria
{
  compressor_id: number,
  sensor_id: number,
  rms: number,
  temperatura: number,
  estado_trabalho: 'carga' | 'vazio' | 'desligado',
  timestamp: Date
}

// Alerta
{
  compressorId: number,
  mensagem: string,
  tipo: 'vibracao' | 'manutencao' | 'calibracao',
  timestamp: Date,
  nivel: 'info' | 'warning' | 'error'
}
🎨 Personalização
Tema
O tema pode ser personalizado no arquivo App.jsx através do createTheme do Material-UI.

Cores de Status
🟢 Operando: #4CAF50

🟡 Manutenção: #FFA726

🔴 Falha: #f44336

⚪ Desligado: #9e9e9e

🔄 Fluxo de Dados
Conexão WebSocket estabelecida ao iniciar a aplicação

Dados em tempo real atualizam automaticamente os cards e gráficos

Alertas são exibidos na lista de alertas e como Toasts

Ações de manutenção criam ordens de serviço via API REST

Atualizações são refletidas em toda a aplicação

🧪 Testes
bash
# Executar testes
npm test

# Build de produção
npm run build
📝 Licença
Este projeto é proprietário e confidencial.

👥 Equipe
Desenvolvido pela equipe de engenharia de manutenção preditiva.

text

Agora sim, seguindo exatamente a estrutura solicitada com arquivos JSX (JavaScript) ao invés de TypeScript, com todos os componentes, páginas, contextos e serviços devidamente organizados!
