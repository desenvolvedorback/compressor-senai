// src/App.jsx
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import CssBaseline from '@mui/material/CssBaseline';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

import { SocketProvider } from './contexts/SocketContext';
import Dashboard from './pages/Dashboard';
import AnaliseMecanica from './pages/AnaliseMecanica';
import Manutencao from './pages/Manutencao';
import Navigation from './components/Navigation';

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
    background: {
      default: '#f5f5f5',
    },
  },
});

const App = () => {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <SocketProvider>
        <Router>
          <Navigation />
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/analise/:id" element={<AnaliseMecanica />} />
            <Route path="/manutencao" element={<Manutencao />} />
          </Routes>
        </Router>
        <ToastContainer position="bottom-right" theme="colored" />
      </SocketProvider>
    </ThemeProvider>
  );
};

export default App;