// src/services/api.js
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3000/api/v1';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// GET /compressores -> Retorna lista de compressores com status e horímetro atual
export const listarCompressores = async () => {
  const response = await api.get('/compressores');
  return response.data;
};

// GET /compressores/:id/dashboard -> Dados consolidados das últimas 24h
export const getDashboardData = async (id) => {
  const response = await api.get(`/compressores/${id}/dashboard`);
  return response.data;
};

// GET /compressores/:id/vibracao-historico -> Dados brutos e FFT
export const getHistoricoVibracao = async (id, params = {}) => {
  const response = await api.get(`/compressores/${id}/vibracao-historico`, { params });
  return response.data;
};

// POST /manutencao/ordens -> Abertura manual ou automática de ordens de serviço
export const criarOrdemServico = async (ordem) => {
  const response = await api.post('/manutencao/ordens', ordem);
  return response.data;
};

// GET /manutencao/preventivas-pendentes -> Lista o que está próximo do gatilho
export const getPreventivasPendentes = async () => {
  const response = await api.get('/manutencao/preventivas-pendentes');
  return response.data;
};

// POST /sensores/calibracao -> Atualiza a data de calibração do sensor
export const atualizarCalibracao = async (sensorId, dataCalibracao) => {
  const response = await api.post('/sensores/calibracao', { 
    sensor_id: sensorId, 
    data_calibracao: dataCalibracao 
  });
  return response.data;
};

export default api;