// src/pages/Manutencao.jsx
import React, { useEffect, useState } from 'react';
import {
  Container,
  Typography,
  Grid,
  Paper,
  Box,
  CircularProgress,
  Alert,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  MenuItem,
  Snackbar,
} from '@mui/material';
import { Add as AddIcon } from '@mui/icons-material';
import { getPreventivasPendentes, criarOrdemServico } from '../services/api';
import TabelaPreventivas from '../components/TabelaPreventivas';

const Manutencao = () => {
  const [planosPreventiva, setPlanosPreventiva] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [snackbar, setSnackbar] = useState({
    open: false,
    message: '',
    severity: 'success',
  });

  useEffect(() => {
    carregarDados();
  }, []);

  const carregarDados = async () => {
    try {
      setLoading(true);
      const preventivas = await getPreventivasPendentes();
      setPlanosPreventiva(preventivas);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar dados de manutenção');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleExecutarPreventiva = async (planoId) => {
    try {
      await criarOrdemServico({
        plano_id: planoId,
        tipo: 'preventiva',
        status: 'aberta',
        descricao_problema: 'Execução de manutenção preventiva programada',
        prioridade: 'media',
      });

      setSnackbar({
        open: true,
        message: 'Ordem de serviço preventiva criada com sucesso!',
        severity: 'success',
      });

      carregarDados();
    } catch (err) {
      console.error('Erro ao executar preventiva:', err);
      setSnackbar({
        open: true,
        message: 'Erro ao executar preventiva',
        severity: 'error',
      });
    }
  };

  const handleCriarOrdemManual = async (event) => {
    event.preventDefault();
    const formData = new FormData(event.currentTarget);
    
    try {
      await criarOrdemServico({
        compressor_id: parseInt(formData.get('compressorId')),
        tipo: formData.get('tipo'),
        status: 'aberta',
        descricao_problema: formData.get('descricao'),
        prioridade: formData.get('prioridade'),
      });

      setSnackbar({
        open: true,
        message: 'Ordem de serviço criada com sucesso!',
        severity: 'success',
      });
      setDialogOpen(false);
      carregarDados();
    } catch (err) {
      console.error('Erro ao criar ordem:', err);
      setSnackbar({
        open: true,
        message: 'Erro ao criar ordem de serviço',
        severity: 'error',
      });
    }
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Gestão de Manutenção
        </Typography>
        <Button
          variant="contained"
          startIcon={<AddIcon />}
          onClick={() => setDialogOpen(true)}
        >
          Nova Ordem de Serviço
        </Button>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Tabela de Preventivas */}
      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Typography variant="h6" gutterBottom>
            Manutenções Preventivas Pendentes
          </Typography>
          <TabelaPreventivas 
            planos={planosPreventiva} 
            onExecutarPreventiva={handleExecutarPreventiva}
          />
        </Grid>
      </Grid>

      {/* Dialog para criar ordem manual */}
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
        <form onSubmit={handleCriarOrdemManual}>
          <DialogTitle>Nova Ordem de Serviço</DialogTitle>
          <DialogContent>
            <Grid container spacing={2} sx={{ mt: 1 }}>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Compressor ID"
                  name="compressorId"
                  type="number"
                  required
                />
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  select
                  label="Tipo"
                  name="tipo"
                  required
                  defaultValue="preventiva"
                >
                  <MenuItem value="preventiva">Preventiva</MenuItem>
                  <MenuItem value="corretiva">Corretiva</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  select
                  label="Prioridade"
                  name="prioridade"
                  required
                  defaultValue="media"
                >
                  <MenuItem value="baixa">Baixa</MenuItem>
                  <MenuItem value="media">Média</MenuItem>
                  <MenuItem value="alta">Alta</MenuItem>
                  <MenuItem value="critica">Crítica</MenuItem>
                </TextField>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  fullWidth
                  label="Descrição"
                  name="descricao"
                  multiline
                  rows={3}
                  required
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setDialogOpen(false)}>Cancelar</Button>
            <Button type="submit" variant="contained">
              Criar Ordem
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Snackbar para feedback */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={() => setSnackbar({ ...snackbar, open: false })}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'center' }}
      >
        <Alert 
          severity={snackbar.severity} 
          onClose={() => setSnackbar({ ...snackbar, open: false })}
        >
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Manutencao;