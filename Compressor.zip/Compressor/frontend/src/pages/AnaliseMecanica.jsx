// src/pages/AnaliseMecanica.jsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Paper,
  Typography,
  Box,
  CircularProgress,
  Alert,
  Tabs,
  Tab,
  Button,
  IconButton,
} from '@mui/material';
import { ArrowBack as ArrowBackIcon } from '@mui/icons-material';
import GraficoLinha from '../components/GraficoLinha';
import { getDashboardData, getHistoricoVibracao } from '../services/api';
import { useSocket } from '../contexts/SocketContext';

const TabPanel = ({ children, value, index, ...other }) => {
  return (
    <div hidden={value !== index} {...other}>
      {value === index && <Box sx={{ p: 3 }}>{children}</Box>}
    </div>
  );
};

const AnaliseMecanica = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [compressor, setCompressor] = useState(null);
  const [historicoVibracao, setHistoricoVibracao] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tabValue, setTabValue] = useState(0);
  const { ultimaTelemetria, isConnected } = useSocket();

  useEffect(() => {
    if (id) {
      carregarDados(parseInt(id));
    }
  }, [id]);

  useEffect(() => {
    if (ultimaTelemetria && compressor && ultimaTelemetria.compressor_id === compressor.id) {
      setHistoricoVibracao(prev => {
        const novoPonto = {
          timestamp: new Date(),
          rms: ultimaTelemetria.rms,
          temperatura: ultimaTelemetria.temperatura,
        };
        const updated = [...prev, novoPonto];
        return updated.slice(-100);
      });
    }
  }, [ultimaTelemetria, compressor]);

  const carregarDados = async (compressorId) => {
    try {
      setLoading(true);
      const dashboardData = await getDashboardData(compressorId);
      setCompressor(dashboardData.compressor);

      const historico = await getHistoricoVibracao(compressorId, { horas: 24 });
      setHistoricoVibracao(historico.leituras || []);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar dados do compressor');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error || !compressor) {
    return (
      <Container>
        <Alert severity="error">{error || 'Compressor não encontrado'}</Alert>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/')} sx={{ mt: 2 }}>
          Voltar ao Dashboard
        </Button>
      </Container>
    );
  }

  const dadosGrafico = historicoVibracao.map(item => ({
    timestamp: new Date(item.timestamp),
    rms: item.rms,
    temperatura: item.temperatura,
  }));

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Header */}
      <Box display="flex" alignItems="center" gap={2} mb={3}>
        <IconButton onClick={() => navigate('/')}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h4" component="h1">
          {compressor.nome} - Análise Mecânica
        </Typography>
        <Box ml="auto" display="flex" alignItems="center" gap={2}>
          <Typography variant="body2" color={isConnected ? 'success.main' : 'error.main'}>
            {isConnected ? '🟢 Dados em tempo real' : '🔴 Conectando...'}
          </Typography>
          <Paper sx={{ px: 2, py: 0.5 }}>
            <Typography variant="caption">
              Status: {compressor.status}
            </Typography>
          </Paper>
        </Box>
      </Box>

      {/* Tabs */}
      <Paper sx={{ width: '100%' }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Vibração RMS" />
          <Tab label="Análise FFT" />
          <Tab label="Temperatura" />
          <Tab label="Dados Técnicos" />
        </Tabs>

        {/* Painel de Vibração RMS */}
        <TabPanel value={tabValue} index={0}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <Paper sx={{ p: 2 }}>
                <GraficoLinha
                  data={dadosGrafico}
                  title="Vibração RMS - Últimas 24h"
                  lines={[
                    { dataKey: 'rms', stroke: '#2196f3', name: 'RMS (mm/s)' }
                  ]}
                  alerta={compressor.limite_vibracao_alerta}
                  critico={compressor.limite_vibracao_critico}
                  height={400}
                />
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Estatísticas
                </Typography>
                <Box>
                  <Typography variant="body2">
                    Média: {(dadosGrafico.reduce((acc, curr) => acc + curr.rms, 0) / dadosGrafico.length || 0).toFixed(2)} mm/s
                  </Typography>
                  <Typography variant="body2">
                    Máximo: {(Math.max(...dadosGrafico.map(d => d.rms)) || 0).toFixed(2)} mm/s
                  </Typography>
                  <Typography variant="body2">
                    Mínimo: {(Math.min(...dadosGrafico.map(d => d.rms)) || 0).toFixed(2)} mm/s
                  </Typography>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Normas ISO 10816-3
                </Typography>
                <Box>
                  <Typography variant="body2" color="textSecondary">
                    Zona A (Verde): {(compressor.limite_vibracao_alerta * 0.5).toFixed(2)} mm/s
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Zona B (Amarelo): {compressor.limite_vibracao_alerta.toFixed(2)} mm/s
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Zona C (Laranja): {compressor.limite_vibracao_critico.toFixed(2)} mm/s
                  </Typography>
                  <Typography variant="body2" color="textSecondary">
                    Zona D (Vermelho): Acima de {compressor.limite_vibracao_critico.toFixed(2)} mm/s
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </TabPanel>

        {/* Painel FFT */}
        <TabPanel value={tabValue} index={1}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Análise de Espectro FFT
            </Typography>
            <Alert severity="info" sx={{ mb: 2 }}>
              A análise FFT permite identificar desalinhamento, desbalanceamento e folgas mecânicas.
              Frequências características: 1x (desbalanceamento), 2x (desalinhamento), harmônicas (folgas).
            </Alert>
            <Box height={400} display="flex" alignItems="center" justifyContent="center">
              <Typography variant="body1" color="textSecondary">
                Dados FFT serão exibidos aqui (requer dados do sensor)
              </Typography>
            </Box>
          </Paper>
        </TabPanel>

        {/* Painel Temperatura */}
        <TabPanel value={tabValue} index={2}>
          <Paper sx={{ p: 2 }}>
            <GraficoLinha
              data={dadosGrafico}
              title="Temperatura - Últimas 24h"
              lines={[
                { dataKey: 'temperatura', stroke: '#ff5722', name: 'Temperatura (°C)' }
              ]}
              height={400}
            />
          </Paper>
        </TabPanel>

        {/* Painel Dados Técnicos */}
        <TabPanel value={tabValue} index={3}>
          <Grid container spacing={3}>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Informações do Compressor
                </Typography>
                <Box>
                  <Typography><strong>Modelo:</strong> {compressor.modelo}</Typography>
                  <Typography><strong>Horímetro Total:</strong> {compressor.horimetro_total}h</Typography>
                  <Typography><strong>Status:</strong> {compressor.status}</Typography>
                  <Typography><strong>Limite Alerta:</strong> {compressor.limite_vibracao_alerta} mm/s</Typography>
                  <Typography><strong>Limite Crítico:</strong> {compressor.limite_vibracao_critico} mm/s</Typography>
                </Box>
              </Paper>
            </Grid>
            <Grid item xs={12} md={6}>
              <Paper sx={{ p: 2 }}>
                <Typography variant="subtitle1" gutterBottom>
                  Última Leitura
                </Typography>
                {compressor.ultima_leitura && (
                  <Box>
                    <Typography><strong>RMS:</strong> {compressor.ultima_leitura.rms} mm/s</Typography>
                    <Typography><strong>Temperatura:</strong> {compressor.ultima_leitura.temperatura}°C</Typography>
                    <Typography><strong>Estado:</strong> {compressor.ultima_leitura.estado_trabalho}</Typography>
                    <Typography><strong>Data:</strong> {new Date(compressor.ultima_leitura.timestamp).toLocaleString('pt-BR')}</Typography>
                  </Box>
                )}
              </Paper>
            </Grid>
          </Grid>
        </TabPanel>
      </Paper>
    </Container>
  );
};

export default AnaliseMecanica;