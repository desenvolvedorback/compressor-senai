// src/pages/Dashboard.jsx
import React, { useEffect, useState } from 'react';
import {
  Grid,
  Box,
  Typography,
  Container,
  CircularProgress,
  Alert,
  Paper,
} from '@mui/material';
import { useSocket } from '../contexts/SocketContext';
import { listarCompressores } from '../services/api';
import CardCompressor from '../components/CardCompressor';
import ListaAlertas from '../components/ListaAlertas';
import { useNavigate } from 'react-router-dom';

const Dashboard = () => {
  const [compressores, setCompressores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { ultimaTelemetria, alertasRecentes, isConnected } = useSocket();
  const navigate = useNavigate();

  useEffect(() => {
    carregarCompressores();
  }, []);

  useEffect(() => {
    if (ultimaTelemetria) {
      atualizarCompressor(ultimaTelemetria);
    }
  }, [ultimaTelemetria]);

  const carregarCompressores = async () => {
    try {
      setLoading(true);
      const data = await listarCompressores();
      setCompressores(data);
      setError(null);
    } catch (err) {
      setError('Erro ao carregar compressores');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const atualizarCompressor = (telemetria) => {
    setCompressores(prev => 
      prev.map(comp => {
        if (comp.id === telemetria.compressor_id) {
          return {
            ...comp,
            ultima_leitura: {
              ...telemetria,
              id: 0,
              sensor_id: telemetria.sensor_id,
              pressao: 0,
              fft_data: [],
              timestamp: new Date(),
            },
          };
        }
        return comp;
      })
    );
  };

  const handleCardClick = (compressorId) => {
    navigate(`/analise/${compressorId}`);
  };

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      {/* Header com status da conexão */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4" component="h1">
          Dashboard de Compressores
        </Typography>
        <Box display="flex" alignItems="center" gap={2}>
          <Typography variant="body2" color={isConnected ? 'success.main' : 'error.main'}>
            {isConnected ? '🟢 Conectado' : '🔴 Desconectado'}
          </Typography>
          <Paper sx={{ px: 2, py: 0.5 }}>
            <Typography variant="caption">
              {new Date().toLocaleString('pt-BR')}
            </Typography>
          </Paper>
        </Box>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>
          {error}
        </Alert>
      )}

      {/* Grid de compressores */}
      <Grid container spacing={3}>
        {compressores.map((compressor) => (
          <Grid item xs={12} sm={6} md={4} lg={3} key={compressor.id}>
            <CardCompressor 
              compressor={compressor} 
              onClick={() => handleCardClick(compressor.id)}
            />
          </Grid>
        ))}
      </Grid>

      {/* Alertas em tempo real */}
      <Box mt={4}>
        <Typography variant="h6" gutterBottom>
          Alertas em Tempo Real
        </Typography>
        <ListaAlertas alertas={alertasRecentes} maxItems={10} />
      </Box>

      {/* Estatísticas rápidas */}
      <Grid container spacing={2} mt={2}>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="textSecondary">
              Total de Compressores
            </Typography>
            <Typography variant="h4">
              {compressores.length}
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="textSecondary">
              Em Operação
            </Typography>
            <Typography variant="h4" color="success.main">
              {compressores.filter(c => c.status === 'operando').length}
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="subtitle2" color="textSecondary">
              Com Falha
            </Typography>
            <Typography variant="h4" color="error.main">
              {compressores.filter(c => c.status === 'falha').length}
            </Typography>
          </Paper>
        </Grid>
      </Grid>
    </Container>
  );
};

export default Dashboard;