// src/contexts/SocketContext.jsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import io from 'socket.io-client';

const SocketContext = createContext(null);

export const useSocket = () => {
  const context = useContext(SocketContext);
  if (!context) {
    throw new Error('useSocket must be used within a SocketProvider');
  }
  return context;
};

export const SocketProvider = ({ children }) => {
  const [socket, setSocket] = useState(null);
  const [ultimaTelemetria, setUltimaTelemetria] = useState(null);
  const [alertasRecentes, setAlertasRecentes] = useState([]);
  const [isConnected, setIsConnected] = useState(false);

  useEffect(() => {
    const newSocket = io(process.env.REACT_APP_WS_URL || 'http://localhost:3000', {
      transports: ['websocket'],
    });

    newSocket.on('connect', () => {
      setIsConnected(true);
      console.log('🟢 WebSocket conectado');
    });

    newSocket.on('disconnect', () => {
      setIsConnected(false);
      console.log('🔴 WebSocket desconectado');
    });

    // Evento telemetria:painel (Saída) - Emite os dados limpos para os navegadores
    newSocket.on('telemetria:painel', (data) => {
      setUltimaTelemetria(data);
    });

    // Alerta de manutenção
    newSocket.on('alerta:manutencao', (alerta) => {
      setAlertasRecentes(prev => [alerta, ...prev].slice(0, 50));
    });

    // Alerta de vibração crítica
    newSocket.on('alerta:vibracao', (alerta) => {
      setAlertasRecentes(prev => [alerta, ...prev].slice(0, 50));
    });

    setSocket(newSocket);

    return () => {
      newSocket.close();
    };
  }, []);

  const value = {
    socket,
    ultimaTelemetria,
    alertasRecentes,
    isConnected,
  };

  return (
    <SocketContext.Provider value={value}>
      {children}
    </SocketContext.Provider>
  );
};