// src/components/CardCompressor.jsx
import React from 'react';
import { Card, CardContent, Typography, Box, LinearProgress, Chip } from '@mui/material';
import { styled } from '@mui/material/styles';

const StatusIndicator = styled('div')(({ status }) => ({
  width: 12,
  height: 12,
  borderRadius: '50%',
  backgroundColor: status === 'operando' ? '#4CAF50' : 
                   status === 'falha' ? '#f44336' :
                   status === 'manutencao' ? '#FFA726' : '#9e9e9e',
  display: 'inline-block',
  marginRight: 8,
  animation: status === 'operando' ? 'pulse 2s infinite' : 'none',
  '@keyframes pulse': {
    '0%': { opacity: 1 },
    '50%': { opacity: 0.5 },
    '100%': { opacity: 1 },
  },
}));

const CardCompressor = ({ compressor, onClick }) => {
  const getStatusText = (status) => {
    const map = {
      operando: 'Operando',
      falha: 'Falha',
      manutencao: 'Manutenção',
      desligado: 'Desligado',
    };
    return map[status] || status;
  };

  const getProgressColor = (horasRestantes) => {
    if (horasRestantes <= 0) return 'error';
    if (horasRestantes <= 200) return 'warning';
    return 'primary';
  };

  const progressValue = compressor.horas_para_preventiva !== undefined 
    ? Math.min((1 - compressor.horas_para_preventiva / 2000) * 100, 100) 
    : 0;

  return (
    <Card 
      sx={{ 
        minWidth: 200, 
        cursor: onClick ? 'pointer' : 'default',
        transition: 'all 0.3s',
        '&:hover': onClick ? { 
          boxShadow: 6, 
          transform: 'translateY(-4px)' 
        } : {},
      }}
      onClick={onClick}
    >
      <CardContent>
        <Box display="flex" alignItems="center" justifyContent="space-between" mb={1}>
          <Typography variant="h6" component="div" noWrap>
            {compressor.nome}
          </Typography>
          <Box display="flex" alignItems="center">
            <StatusIndicator status={compressor.status} />
            <Typography variant="caption" color="textSecondary">
              {getStatusText(compressor.status)}
            </Typography>
          </Box>
        </Box>

        <Typography variant="body2" color="textSecondary" gutterBottom>
          Modelo: {compressor.modelo}
        </Typography>

        <Box display="flex" justifyContent="space-between" mt={2}>
          <Box>
            <Typography variant="caption" color="textSecondary">
              Horímetro
            </Typography>
            <Typography variant="h6">
              {compressor.horimetro_total?.toFixed(1) || 0}h
            </Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="textSecondary">
              RMS Atual
            </Typography>
            <Typography 
              variant="h6" 
              color={compressor.ultima_leitura?.rms && 
                     compressor.ultima_leitura.rms > compressor.limite_vibracao_critico ? 
                     'error' : 'textPrimary'}
            >
              {compressor.ultima_leitura?.rms?.toFixed(2) || 0} mm/s
            </Typography>
          </Box>
          <Box>
            <Typography variant="caption" color="textSecondary">
              Estado
            </Typography>
            <Chip 
              label={compressor.ultima_leitura?.estado_trabalho || 'N/A'} 
              size="small"
              color={compressor.ultima_leitura?.estado_trabalho === 'carga' ? 'success' : 'default'}
            />
          </Box>
        </Box>

        {compressor.horas_para_preventiva !== undefined && (
          <Box mt={2}>
            <Box display="flex" justifyContent="space-between" alignItems="center">
              <Typography variant="caption" color="textSecondary">
                Próxima Preventiva
              </Typography>
              <Typography variant="caption" color={getProgressColor(compressor.horas_para_preventiva)}>
                {compressor.horas_para_preventiva > 0 ? 
                  `${compressor.horas_para_preventiva.toFixed(0)}h` : 'Vencida'}
              </Typography>
            </Box>
            <LinearProgress 
              variant="determinate" 
              value={progressValue} 
              color={getProgressColor(compressor.horas_para_preventiva)}
              sx={{ height: 8, borderRadius: 4 }}
            />
          </Box>
        )}
      </CardContent>
    </Card>
  );
};

export default CardCompressor;