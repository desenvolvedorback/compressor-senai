// src/components/ListaAlertas.jsx
import React, { useState, useEffect } from 'react';
import { 
  List, 
  ListItem, 
  ListItemText, 
  ListItemIcon, 
  Paper, 
  Typography, 
  Box,
  Chip,
  IconButton
} from '@mui/material';
import { 
  Warning as WarningIcon, 
  Error as ErrorIcon,
  Info as InfoIcon,
  Close as CloseIcon,
  Build as BuildIcon
} from '@mui/icons-material';
import { formatDistanceToNow } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const ListaAlertas = ({ alertas, maxItems = 20 }) => {
  const [items, setItems] = useState([]);

  useEffect(() => {
    setItems(alertas.slice(0, maxItems));
  }, [alertas, maxItems]);

  const getIcon = (nivel, tipo) => {
    if (nivel === 'error') return <ErrorIcon color="error" />;
    if (nivel === 'warning') return <WarningIcon color="warning" />;
    if (tipo === 'manutencao') return <BuildIcon color="info" />;
    return <InfoIcon color="info" />;
  };

  const getColor = (nivel) => {
    const map = {
      info: '#2196f3',
      warning: '#ff9800',
      error: '#f44336'
    };
    return map[nivel] || '#2196f3';
  };

  const handleRemove = (index) => {
    setItems(prev => prev.filter((_, i) => i !== index));
  };

  if (items.length === 0) {
    return (
      <Paper sx={{ p: 2, textAlign: 'center' }}>
        <Typography variant="body2" color="textSecondary">
          Nenhum alerta recente
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper sx={{ maxHeight: 400, overflow: 'auto' }}>
      <List dense>
        {items.map((alerta, index) => (
          <ListItem 
            key={index}
            sx={{
              borderLeft: `4px solid ${getColor(alerta.nivel)}`,
              '&:hover': { backgroundColor: 'action.hover' }
            }}
            secondaryAction={
              <IconButton edge="end" size="small" onClick={() => handleRemove(index)}>
                <CloseIcon fontSize="small" />
              </IconButton>
            }
          >
            <ListItemIcon>
              {getIcon(alerta.nivel, alerta.tipo)}
            </ListItemIcon>
            <ListItemText
              primary={
                <Box display="flex" alignItems="center" gap={1}>
                  <Typography variant="body2">
                    Compressor #{alerta.compressorId}
                  </Typography>
                  <Chip 
                    label={alerta.tipo} 
                    size="small" 
                    color={alerta.nivel === 'error' ? 'error' : 'default'}
                  />
                </Box>
              }
              secondary={
                <>
                  <Typography variant="body2" color="textSecondary">
                    {alerta.mensagem}
                  </Typography>
                  <Typography variant="caption" color="textSecondary">
                    {formatDistanceToNow(new Date(alerta.timestamp), { 
                      addSuffix: true,
                      locale: ptBR 
                    })}
                  </Typography>
                </>
              }
            />
          </ListItem>
        ))}
      </List>
    </Paper>
  );
};

export default ListaAlertas;