// src/components/GraficoLinha.jsx
import React from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  ReferenceLine,
  ResponsiveContainer
} from 'recharts';
import { Box, Paper, Typography } from '@mui/material';

const GraficoLinha = ({ 
  data, 
  title, 
  lines, 
  alerta, 
  critico,
  height = 400 
}) => {
  const formatXAxis = (timestamp) => {
    return new Date(timestamp).toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload.length) {
      return (
        <Paper sx={{ p: 1 }}>
          <Typography variant="caption" display="block">
            {new Date(label).toLocaleString('pt-BR')}
          </Typography>
          {payload.map((entry, index) => (
            <Typography key={index} variant="body2" color={entry.color}>
              {entry.name}: {entry.value.toFixed(2)}
            </Typography>
          ))}
        </Paper>
      );
    }
    return null;
  };

  return (
    <Box>
      {title && (
        <Typography variant="h6" gutterBottom>
          {title}
        </Typography>
      )}
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis 
            dataKey="timestamp" 
            tickFormatter={formatXAxis}
            interval="preserveStartEnd"
          />
          <YAxis />
          <Tooltip content={<CustomTooltip />} />
          <Legend />
          
          {lines.map((line, index) => (
            <Line
              key={index}
              type="monotone"
              dataKey={line.dataKey}
              stroke={line.stroke}
              name={line.name}
              dot={false}
              strokeWidth={2}
            />
          ))}
          
          {alerta && (
            <ReferenceLine 
              y={alerta} 
              stroke="#FFA726" 
              strokeDasharray="3 3"
              label={{ value: `Alerta: ${alerta} mm/s`, fill: '#FFA726' }}
            />
          )}
          
          {critico && (
            <ReferenceLine 
              y={critico} 
              stroke="#f44336" 
              strokeDasharray="3 3"
              label={{ value: `Crítico: ${critico} mm/s`, fill: '#f44336' }}
            />
          )}
        </LineChart>
      </ResponsiveContainer>
    </Box>
  );
};

export default GraficoLinha;