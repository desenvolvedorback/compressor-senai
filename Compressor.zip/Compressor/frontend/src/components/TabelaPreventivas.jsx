// src/components/TabelaPreventivas.jsx
import React, { useState } from 'react';
import {
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Chip,
  Button,
  Box,
  Typography,
  LinearProgress,
  Tooltip,
} from '@mui/material';
import { 
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Error as ErrorIcon,
  Schedule as ScheduleIcon
} from '@mui/icons-material';
import { format, differenceInDays } from 'date-fns';
import { ptBR } from 'date-fns/locale';

const TabelaPreventivas = ({ planos, onExecutarPreventiva }) => {
  const [executando, setExecutando] = useState(null);

  const getStatusChip = (plano) => {
    const hoje = new Date();
    const diasAteRevisao = differenceInDays(new Date(plano.proxima_revisao_data), hoje);
    const horasAteRevisao = plano.proxima_revisao_horas - (plano.ultima_execucao ? 0 : 0);
    
    if (diasAteRevisao <= 0 || horasAteRevisao <= 0) {
      return {
        label: 'Vencida',
        color: 'error',
        icon: <ErrorIcon />
      };
    }
    
    if (diasAteRevisao <= 15 || horasAteRevisao <= 200) {
      return {
        label: 'Próximo',
        color: 'warning',
        icon: <WarningIcon />
      };
    }
    
    return {
      label: 'Em dia',
      color: 'success',
      icon: <CheckCircleIcon />
    };
  };

  const getProgresso = (plano) => {
    const hoje = new Date();
    const diasAteRevisao = differenceInDays(new Date(plano.proxima_revisao_data), hoje);
    const totalDias = plano.intervalo_dias || 365;
    const progresso = ((totalDias - diasAteRevisao) / totalDias) * 100;
    return Math.min(Math.max(progresso, 0), 100);
  };

  const handleExecutar = async (planoId) => {
    setExecutando(planoId);
    await onExecutarPreventiva(planoId);
    setExecutando(null);
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Plano</TableCell>
            <TableCell>Descrição</TableCell>
            <TableCell align="center">Status</TableCell>
            <TableCell align="center">Progresso</TableCell>
            <TableCell align="center">Próxima Revisão</TableCell>
            <TableCell align="center">Ações</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {planos.map((plano) => {
            const status = getStatusChip(plano);
            const progresso = getProgresso(plano);
            
            return (
              <TableRow key={plano.id}>
                <TableCell>
                  <Typography variant="body2" fontWeight="bold">
                    Plano #{plano.id}
                  </Typography>
                </TableCell>
                <TableCell>{plano.descricao}</TableCell>
                <TableCell align="center">
                  <Chip
                    label={status.label}
                    color={status.color}
                    icon={status.icon}
                    size="small"
                  />
                </TableCell>
                <TableCell align="center">
                  <Box display="flex" alignItems="center" justifyContent="center" gap={1}>
                    <Box sx={{ width: 100 }}>
                      <LinearProgress 
                        variant="determinate" 
                        value={progresso}
                        color={status.color}
                        sx={{ height: 8, borderRadius: 4 }}
                      />
                    </Box>
                    <Typography variant="caption">
                      {progresso.toFixed(0)}%
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell align="center">
                  <Box>
                    <Typography variant="body2">
                      {format(new Date(plano.proxima_revisao_data), 'dd/MM/yyyy', { locale: ptBR })}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      {plano.proxima_revisao_horas}h
                    </Typography>
                  </Box>
                </TableCell>
                <TableCell align="center">
                  <Tooltip title="Executar preventiva">
                    <span>
                      <Button
                        variant="contained"
                        size="small"
                        startIcon={<ScheduleIcon />}
                        onClick={() => handleExecutar(plano.id)}
                        disabled={executando === plano.id || status.color === 'error'}
                      >
                        Executar
                      </Button>
                    </span>
                  </Tooltip>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default TabelaPreventivas;