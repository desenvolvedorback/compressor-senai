# 🛠️ Sistema de Monitoramento de Compressores — Banco de Dados

Este repositório contém a estrutura de modelagem de dados (PostgreSQL) projetada para o monitoramento em tempo real, telemetria (IoT) e gestão de manutenção (preventiva, corretiva e preditiva) de compressores industriais.

---

## 📊 Arquitetura do Banco de Dados

O banco `monitoramento_compressores` foi modelado para suportar alta frequência de inserção de dados (telemetria) e garantir a rastreabilidade total do ciclo de vida dos ativos, desde a coleta dos sensores até a execução de ordens de serviço.

### 🏗️ Entidades e Dicionário de Dados

#### 1. Compressores (`compressores`)
Centraliza o cadastro dos ativos físicos da planta industrial.
* **Campos de Destaque:**
    * `tag`: Identificador único operacional (Ex: `COMP-01`).
    * `status`: Estado atual do equipamento limitado por regras (`operando`, `manutencao`, `parado`, `falha`).
    * `limites de vibração`: Parâmetros (`alerta` e `crítico`) baseados na norma ISO 10816 para monitoramento de severidade vibratória.

#### 2. Sensores (`sensores`)
Cadastro dos dispositivos IoT acoplados aos compressores.
* **Campos de Destaque:**
    * `tipo`: Suporta grandezas de `vibracao`, `temperatura`, `pressao` e `horimetro`.
    * `status`: Rastreia a saúde do sensor (`ativo`, `defeito`, `descalibrado`).

#### 3. Leituras dos Sensores (`leituras_sensores`)
Tabela de alta volumetria (Time-Series) que armazena o histórico de telemetria.
* **Campos de Destaque:**
    * `valor_rms`: Valor global da vibração em mm/s.
    * `valor_fft`: Campo de texto preparado para receber payloads (JSON/String) com o espectro de frequência para análise de falhas na assinatura do compressor.
    * `timestamp`: Registro temporal exato da coleta.

#### 4. Registro de Trabalho (`registro_trabalho`)
Monitora a eficiência operacional do equipamento.
* **Campos de Destaque:**
    * `tipo_estado`: Diferencia se o compressor operou em **carga** (gerando ar) ou **vazio** (aliviado/consumindo apenas energia).
    * `horas_calculadas`: Coluna gerada automaticamente (`GENERATED ALWAYS`) que calcula em tempo real o tempo de operação em horas através da diferença dos timestamps.

#### 5. Planos de Preventiva (`planos_preventiva`)
Armazena a inteligência e as regras de negócio das manutenções programadas.
* **Campos de Destaque:**
    * Baseia-se no conceito de "o que ocorrer primeiro" entre o **intervalo de horas** de funcionamento ou **intervalo de meses**.

#### 6. Ordens de Manutenção (`ordens_manutencao`)
Workflow completo para o time de manutenção.
* **Campos de Destaque:**
    * `tipo`: Segrega entre manutenções `preventiva`, `corretiva` e `preditiva`.
    * `status`: Controla o ciclo de vida da ordem (`aberta`, `em_execucao`, `concluida`, `cancelada`, `adiada`).

---

## ⚡ Otimização e Performance

Para garantir consultas rápidas em dashboards analíticos e gráficos de tendência de tempo real, foram implementados os seguintes índices:

* **`idx_leituras_timestamp`**: Otimiza buscas ordenadas pelas leituras mais recentes.
* **`idx_leituras_compressor`**: Acelera o filtro de dados históricos por equipamento específico.

---

## 🚀 Como Implantar (PostgreSQL)

1. Conecte-se ao seu servidor PostgreSQL.
2. Crie o banco de dados principal:
   ```sql
   CREATE DATABASE monitoramento_compressores;


   Informações de conexão

Conecte-se com IA

Apache Kafka

Apache Kafka REST

Registro de Esquemas    Método de autenticação

Certificado do cliente      SASL

URI do serviço          kafka-43b8414-compressor.b.aivencloud.com:11520

Hospedar        kafka-43b8414-compressor.b.aivencloud.com

Porta           11520

Usuário                 avnadmin

Senha           AVNS_DKg_VEGLaxRFuTkGvcB


Certificado CA              -----BEGIN CERTIFICATE-----
MIIERDCCAqygAwIBAgIUfJD/c6B40kJHLVd6GRSFXQeKHGUwDQYJKoZIhvcNAQEM
BQAwOjE4MDYGA1UEAwwvM2Y4ZTAzYmYtZjBhNC00NTlhLTk2MTYtMjlmYWY0Njli
MmNkIFByb2plY3QgQ0EwHhcNMjYwNzI0MTY1MTIzWhcNMzYwNzIxMTY1MTIzWjA6
MTgwNgYDVQQDDC8zZjhlMDNiZi1mMGE0LTQ1OWEtOTYxNi0yOWZhZjQ2OWIyY2Qg
UHJvamVjdCBDQTCCAaIwDQYJKoZIhvcNAQEBBQADggGPADCCAYoCggGBALhdX4Jf
5EzqAaZ4RKRnF4W95qVXEPmHXGDKe4sZPZrb/BGrz2Ed65Xa+mbAYtBgYV4a/xZd
h/L+BmzBDLN6x6SEAxecUyrO05LxYDoVIqVxUqXu1Sv6EJ7NMdexIs9VjcKXWdiJ
AhDPgM76iIAStBwsU1AXIEMy65BjvqZzWzMoP9tXfDiZ4uWZngGi7c2EO47VT3ly
0SGJc/Ly1CH/ilIzxAUcOKiYIKhlDxCbtWSqIOjNkFHrIbhaoeMrxxlO8xWnNc5h
8iQ62r0H92Z2I4lBeeN3Gyauxl2RrF1X95puvvucrPr+A/SfCIi7/uH4JFJ5CD2F
osA9i8sPEGiSbSFShDwtqluf5IRlj5qgkcAaDclowlcWrin+Iwk2+jNw+3dy8S0v
I3ob7+tV3xz31UhlQKTa/EcToOa3mcyHtYEGrA3bSvR+7i7Khpkky8BkUDRNghyN
I3Fzjl4FSSkANdDj3k0MM+N4qnBplaJT4nJ936BfCUa02d+WzTuTXtgQvwIDAQAB
o0IwQDAdBgNVHQ4EFgQUziUHWH44AzDtzE73qEk/WkTdiCkwEgYDVR0TAQH/BAgw
BgEB/wIBADALBgNVHQ8EBAMCAQYwDQYJKoZIhvcNAQEMBQADggGBAK4ukdtebsJM
PC+C4/+7SRe4Y6Amas6ukE+vXpbcNJ3KEXFewo7KBukuKroUhl4+daJz7wJPLmJ5
CuQu9OTXse5/W5rdK46zrk7Qk/ZWhxQ/RFcbP4CMbXjg3o5qFJePZiZLEMJm0BW7
iLVls7ulMU3dNcFukQT1/wCtgYegISHjtUj8/+4Yr5n8zdWMHkswIacJNRaIkifl
09VDLLNFVJfLRzzAN/JXoKJlVQua+R9AnF6JDVqP2QrA68rkgNW2pihCOwWJwWgj
6ZIWWUHuDHxi1OiWPBEQIJekVAYJakinrFcNxyucG7An+N2EU2Rm5qRxZyE6wJ7B
ow+Mw7XkONLZHAcIsapsgRk4ON3BI9ReXO9fbPOOvJuOWPGSCKR4UCx8Ij6MDHOx
TYGUd6A8wgs95TBdn2sneCWBQxREOQ295PMikee0gW2Unj+TngKeMgPdLA/ucJR3
po/KUz27HDrRGXWGOhBUgpig/YpovC8SZC7Yl42jZNwv5A0dliyMqg==
-----END CERTIFICATE-----


