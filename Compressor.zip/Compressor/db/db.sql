CREATE DATABASE monitoramento_compressores;

-- 1. Tabela de Compressores
CREATE TABLE compressores (
    id SERIAL PRIMARY KEY,
    tag VARCHAR(50) UNIQUE NOT NULL, -- Ex: COMP-01, COMP-02
    modelo VARCHAR(100) NOT NULL,
    fabricante VARCHAR(100),
    data_instalacao DATE NOT NULL,
    status VARCHAR(20) DEFAULT 'operando' CHECK (status IN ('operando', 'manutencao', 'parado', 'falha')),
    limite_vibracao_alerta REAL DEFAULT 4.5, -- mm/s RMS
    limite_vibracao_critico REAL DEFAULT 7.1,  -- mm/s RMS
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE sensores (
    id SERIAL PRIMARY KEY,
    compressor_id INT REFERENCES compressores(id) ON DELETE CASCADE,
    codigo_sensor VARCHAR(50) UNIQUE NOT NULL, -- Ex: SEN-VIB-01
    tipo VARCHAR(30) NOT NULL, -- 'vibracao', 'temperatura', 'pressao', 'horimetro'
    modelo VARCHAR(100),
    data_ultima_calibracao DATE,
    status VARCHAR(20) DEFAULT 'ativo' CHECK (status IN ('ativo', 'defeito', 'descalibrado'))
);

CREATE TABLE leituras_sensores (
    id BIGSERIAL PRIMARY KEY,
    sensor_id INT REFERENCES sensores(id) ON DELETE CASCADE,
    compressor_id INT REFERENCES compressores(id) ON DELETE CASCADE,
    valor_rms REAL NOT NULL, -- Para vibração ou leitura escalar principal
    valor_fft TEXT, -- Opcional: Dados em JSON/String para espectro de frequência
    temperatura REAL, -- Graus Celsius (se integrado ou leitura combinada)
    pressao REAL, -- Bar / PSI (se aplicável)
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE TABLE registro_trabalho (
    id SERIAL PRIMARY KEY,
    compressor_id INT REFERENCES compressores(id) ON DELETE CASCADE,
    tipo_estado VARCHAR(20) NOT NULL CHECK (tipo_estado IN ('carga', 'vazio')),
    data_inicio TIMESTAMP NOT NULL,
    data_fim TIMESTAMP,
    horas_calculadas REAL GENERATED ALWAYS AS (EXTRACT(EPOCH FROM (data_fim - data_inicio)) / 3600) STORED
);


CREATE TABLE planos_preventiva (
    id SERIAL PRIMARY KEY,
    compressor_id INT REFERENCES compressores(id) ON DELETE CASCADE,
    descricao VARCHAR(255) NOT NULL,
    intervalo_horas INT NOT NULL, -- Ex: A cada 2000 horas
    intervalo_meses INT NOT NULL, -- Ex: A cada 6 meses (o que ocorrer primeiro)
    proxima_revisao_horas INT NOT NULL, -- Valor do horímetro em que deve ocorrer
    proxima_revisao_data DATE NOT NULL
);


CREATE TABLE ordens_manutencao (
    id SERIAL PRIMARY KEY,
    compressor_id INT REFERENCES compressores(id) ON DELETE CASCADE,
    plano_id INT REFERENCES planos_preventiva(id) ON DELETE SET NULL,
    tipo VARCHAR(20) NOT NULL CHECK (tipo IN ('preventiva', 'corretiva', 'preditiva')),
    status VARCHAR(20) DEFAULT 'aberta' CHECK (status IN ('aberta', 'em_execucao', 'concluida', 'cancelada', 'adiada')),
    descricao_problema TEXT,
    acoes_executadas TEXT,
    data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_conclusao TIMESTAMP,
    tecnico_responsavel VARCHAR(100)
);


CREATE INDEX idx_leituras_timestamp ON leituras_sensores(timestamp DESC);
CREATE INDEX idx_leituras_compressor ON leituras_sensores(compressor_id);