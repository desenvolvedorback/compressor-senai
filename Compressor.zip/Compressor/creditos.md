# Esse projeto foi desenvolvido pelos estudantes do SENAI de botucatu.


*Cargos:*
PO (Lucas Daniel)
Escrita (Lucas Daniel) → tem formato padrão (Banner, Powerpoint, Word, PDF)
Front-End (Leonardo Leão)
Back-End(Davi Leonardo)
Banco de Dados (Lucas Daniel)
IOT (Leonardo L. e Davi L. e Lucas D.)
Scrum Master (Davi Leonardo)
Ler (Davi L. e Leonardo L.)
Prototipagem (Leonardo Leão)

# Licença de Uso - Projeto Educacional Proprietário

Copyright (c) 2026 Davi Leonardo; Leonardo Leão; Lucas Daniel

### 1. Termos Gerais
Este software é um projeto puramente educacional. Todos os direitos sobre o código-fonte, arquitetura, documentação e ativos associados são reservados exclusivamente aos autores originais.

### 2. Restrições de Uso e Cópia
* **Proibição de Cópia:** Não é permitida a cópia, reprodução, redistribuição ou duplicação deste código-fonte, seja parcial ou integral, em qualquer meio, sem a autorização prévia e expressa dos autores.
* **Proibição Comercial:** É terminantemente proibida a comercialização, venda, aluguel, licenciamento de terceiros ou qualquer forma de exploração financeira direta ou indireta deste projeto.
* **Proibição de Implementação:** Este sistema não pode ser instalado, hospedado ou utilizado em ambientes de produção ou sistemas de terceiros.

### 3. Utilização mediante Acordo Direto
Qualquer intenção de uso, modificação, adaptação ou integração deste software em outros sistemas só será permitida mediante a celebração de um **contrato formal e direto** assinado com os autores do projeto. Qualquer uso sem este acordo prévio constitui violação de direitos autorais, sujeita às penalidades legais cabíveis.

---
Para solicitações de uso ou dúvidas, entre em contato através de: davi.silva36.senai@gmail.com / (14) 99102-3986
